torch==0.4.0
torchvision
-e git+https://github.com/jeff-sjtu/torchsample.git#egg=torchsample
opencv-python
matplotlib
nibabel
cython
pandas
h5py
scipy
tqdm
pycocotools